# Changelog

All notable changes to `@burgan-tech/pseudo-ui` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

> This file was introduced after `0.3.0` shipped. Entries from `0.3.0` and
> earlier are **reconstructed from git history and the npm publish timeline**, so
> they summarise rather than enumerate. `Unreleased` onward is written as work
> lands. Two known gaps in the reconstruction: `0.1.3` and `0.2.2` have no
> corresponding version bump on this line of history — `0.2.2` is on npm
> (published 2026-07-02) but was released without the bump being committed here.

## [Unreleased]

### Added

- `ForEach.where` — a row filter in the x-conditional rule shape, evaluated
  with the row as the data root (item-relative `field`). Applied before
  `search`; kept rows retain their original index. All three adapters; engine
  `selectForEachRows`.
- `$index` / `$item.` in an input `bind` inside a ForEach template
  (`limits[$index].amount` → `limits.<i>.amount`, `$item.amount` when the
  source is `$form.limits`). The resolved path drives schema lookup,
  validation, `x-conditional` and form writes, so editable lists no longer
  need one static node per row. All three adapters (Vue provide/inject, React
  context, Angular parent-renderer injection); engine `resolveScopedBind`.
- `ForEach.groupBy` — multi-level grouping of the (filtered) rows, each level
  wrapped in its own template with a `ForEachGroupRows` marker for the inner
  level; group templates see `$item` (first row) and `$group`
  (`{ field, value, count, level }`). Groups keep first-seen order and run
  AFTER `pagination` (a group grows as pages arrive). All three adapters;
  engine `groupForEachRows` / `buildGroupRender` / `groupBodyRenders`.
- Row-relative node `x-conditional` inside a ForEach template: `field` may be
  `$item.<path>` or `$group.<path>` (absolute form fields unchanged). All three
  adapters.
- Default logger: without `delegate.onLog`, `warn` / `error` entries reach the
  console (`engine/defaultLog`) so a swallowed pipeline failure is never
  completely silent; `info` / `debug` stay quiet. Dart twin on
  `PseudoViewDelegate.onLog` (`dart:developer`).

## [0.8.6] — 2026-10-14

### Added

- **`x-validation`: `remote` built-in rule — a backend function decides (US
  474570).** A field's verdict can come from a function declared in the schema,
  with no host code: `source` (a function reference, same form as
  `x-lookup.source`), `parameters` (literals or expressions — `$value` is the
  value under validation, `$instance.*` / `$form.*` / `$param.*` / `$ui.*`
  resolve as everywhere; null / empty resolutions are not sent), `resultField`
  (JSONPath of the boolean verdict, default `$.valid`), `messageField` (a
  server-supplied failure message, else `errorMessages[lang]`), `trigger`
  (`change` — debounced, `debounce` ms, default 400 — or `blur`, which text
  inputs report on focus loss) . The request goes through `delegate.requestData`.
  Engine module `remoteValidation.ts`: standard keywords run first; a verdict is
  cached per (field, value) so the same value is never re-asked; an answer for a
  value the user has already changed is dropped; a transport failure counts as
  valid and is logged at `warn`. The submit gate (`dispatchAction`) settles
  pending and missing verdicts before judging the form — the first submit cannot
  pass on an answer that has not arrived — and only awaits when the schema
  declares such a rule. Whole-form passes in all three adapters now keep a
  recorded async verdict (host `onValidationRequest` too — `hasAsyncValidation`)
  instead of wiping it. Dart twin in `remote_validation.dart`.

## [0.8.5] — 2026-10-08

### Added

- **`x-validation`: `maxField` / `minField` built-in rules (US 473344).** The
  value must not exceed / fall below the reference named by `parameters.field` —
  a dotted form-data path or an `$instance.…` expression read from instance
  data (a bank-limit ceiling, where JSON Schema `maximum` cannot help since it
  takes only a literal number). Numeric comparison; non-numeric value or
  reference passes. `validateCrossField` takes `instanceData` as its optional
  fifth argument; all three adapters pass it. Dart twin in `schema_resolver.dart`.

### Fixed

- **`crossFieldDependents` walks nested properties** and returns dotted keys,
  so a rule under `limitDraft.accounts.timeDeposit.daily` that references its
  `…transaction` sibling is re-judged when that sibling changes.

## [0.8.4] — 2026-10-05

### Added

- **Locale-aware `NumberField` (US 471659).** PrimeVue / PrimeReact
  `InputNumber` now receives `locale` (the view language) and the fraction
  digits the schema allows (`integer` → 0, `multipleOf` → its step, else 2)
  via the new engine helper `deriveNumberFormat` (`engine/numberFormat.ts`,
  Dart twin `number_format.dart`). `SchemaProperty.multipleOf` typed.

### Fixed

- **`validateField`: `pattern` / `minLength` / `maxLength` judge strings only.**
  A stored number is no longer stringified and matched against a string
  pattern — a `["string", "number"]` limit property with a Turkish-text
  pattern accepts `400000.5`.

## [0.8.3] — 2026-10-02

### Fixed

- **`Dropdown`: the menu opens below the field, capped in height (Flutter
  only).** The Flutter adapter laid its menu over the field and let a long list
  cover almost the full screen; it is now a Material 3 `DropdownMenu` anchored
  under the field. The web adapters render a native `<select>`, whose popup the
  browser already positions, so nothing changes here; the version moves with
  Dart because the two packages ship at one number. (#471456)

## [0.8.2] — 2026-10-01

### Added

- **`Text.tone`** (vocabulary + Vue/React/Angular): `primary | success |
  error | warning | info | muted` → `.d-text--<tone>` / `.pseudo-text--<tone>`
  on the same tokens as `Icon.variant`; orthogonal to the typography
  `variant`.

### Fixed

- **Icon buttons read in the page foreground; brand emphasis is per node**
  (Vue/React/Angular): `IconButton` now carries `.d-icon-button` in the
  page text colour (`--p-text-color` / `--mat-sys-on-surface`) — never the
  muted icon-only default, never a global accent that would leak into host
  chrome. New `variant` on `IconButton` and `primary` on `Icon.variant`
  (`.d-icon-button--<variant>` / `.d-icon--primary`, `.pseudo-icon--primary`)
  paint the brand accent on the one icon that is the call to action.

### Added

- **`ForEach.pagination`** (vocabulary + Vue/React/Angular): `pageSize`
  windows the loaded rows behind a 'load more' control; a `$lookup.<name>`
  source whose x-lookup declares `pagination` (`param`, `nextField`,
  `sizeParam`, `pageSize`) fetches and appends the next page once every
  loaded row is shown. Engine: `paginateForEach`, `fetchLookupPage`,
  `loadMoreLookup`, `recordLookupPage`; `FormContext.lookupPaging` /
  `loadMoreLookup`. Label from `pagination.label`, else the host's
  `forEach.loadMore` UI string (`samples/ui-strings.json`).

## [0.8.1] — 2026-09-29

### Fixed

- **`Dropdown`: a long option wraps in the menu instead of being cut short
  (Flutter only).** The Flutter adapter drew the same widget in the closed
  field and in the open menu, so the field's ellipsis was truncating every menu
  row and making similar options indistinguishable. The web adapters render a
  native `<select>`, where the browser already wraps, so nothing changes here;
  the version moves with Dart because the two packages ship at one number.
  (#466608)

## [0.8.0] — 2026-09-28

### Removed

- **BREAKING — `x-controlLabels` and `getFieldControlLabel`.** They shipped in
  `0.7.1` and are gone in `0.8.0`, which needs saying plainly: the design in
  #117 put a widget's captions on the bound schema property, beside the field's
  own label and messages, and rejected a host dictionary at the time. That was
  wrong, and the reason is a rule that only became visible once the thing was in
  a real flow. Three kinds of text meet on a screen and each has a different
  owner: the FIELD's words (its caption, why it refused THIS document) belong to
  the schema property; the SCREEN's words belong to the view; and the WIDGET's
  words — "Dosya seç", "Kaldır", "Yükleniyor…" — are identical on every file
  field in every flow and change only with the application's language. Writing
  them on a property meant every schema that ever grows a `FilePicker` carries
  its own copy of "Kaldır", and a typo in one of them is a schema deploy.

- **`FILE_PICKER_UNAVAILABLE`, `FILE_PICKER_READ_FAILED`,
  `FILE_PICKER_READ_FAILED_SHORT`, `FILE_PICKER_MESSAGE_KEYS`,
  `FILE_PICKER_CONTROL_KEYS`, `FILE_PICKER_CONTROL_DEFAULTS`,
  `filePickerControlText`, `FilePickerMessages`.** The package no longer carries
  any of the words a `FilePicker` says.

### Added

- **`PseudoView.uiStrings`** (Vue `ui-strings`, React `uiStrings`, Angular
  `[uiStrings]`) — a host-fed `key → text` map, where a text is either a plain
  string or the same `{tr, en}` shape `x-labels` uses. It is threaded onto
  `FormContext`, stays live when the prop or the language changes, and reaches
  nested `Component` subtrees. See `samples/ui-strings.json`.

- **`engine/uiStrings.ts`** — `resolveUiString(dict, key, lang)`, returning `''`
  for an entry the host has not written. It does not decide the fallback; the
  caller does.

- **`filePicker.*`** — the node's whole vocabulary under one prefix:
  `tooLarge`, `wrongType`, `emptyFile`, `tooMany`, `tooLargeTotal`, `failed`,
  `unavailable`, `none`, `limit`, `limitMulti`, `count`, `choose`, `add`,
  `replace`, `remove`, `clear`, `busy`. Published as `FILE_PICKER_KEYS` /
  `FILE_PICKER_REFUSAL_KEYS` with `filePickerString` and
  `composeFilePickerText`.

- **`BottomSheet.title`** (vocabulary + Vue/React/Angular): rendered as the
  sheet header, like `SideSheet.title`. Flutter draws it as a pinned header
  with a close control above the scrollable body.

### Changed

- **THE KEY IS THE FALLBACK.** An entry the host has not written renders as
  `filePicker.remove` on screen. That is deliberate: an English fallback looks
  correct in review and ships a Turkish screen with English buttons on it, where
  a key is visible to whoever opens the screen and greppable in a repo.

- **A field may still word its OWN refusals** — `x-errorMessages` now takes
  `tooLarge`, `wrongType`, `emptyFile`, `tooMany`, `tooLargeTotal`, `failed`,
  `unavailable` — because "Onay formu 3 MB'ı aşamaz" is about that document on
  that field. It may NOT rename a caption. `composeFilePickerText` is where that
  order (**field → host → key**) is written down, once.

### Migration

Delete `x-controlLabels` from every schema; it is ignored and
`getFieldControlLabel` no longer exists. Rename the refusal keys under
`x-errorMessages`: `oversize` → `tooLarge`, `empty` → `emptyFile`,
`count` → `tooMany`, `total` → `tooLargeTotal`, `readFailed` → `failed`,
`pickerUnavailable` → `unavailable`. Pass `uiStrings` to `PseudoView` — a host
that passes nothing gets keys on screen, which is the intended way to find out.

## [0.7.4] — 2026-09-23

### Fixed

- **Vue: `Component` reloads when its `ref` changes in place.** The nested
  composite was loaded once on mount, so a page whose root `Component` was
  swapped for another composite by the next surface kept the old view and fed
  it the new params. Now watched on `ref` (immediate), matching React's
  `useEffect([ref])` and Angular's `ngOnChanges`. (#465719)

## [0.7.3] — 2026-09-22

### Added

- **Bare-string texts are host localization keys first.** `resolveTextContent`
  offers a plain string (`Text.content`, `Button.label`, any `textContent`) to
  the new optional `PseudoViewDelegate.localizeText(key)` and renders it
  verbatim when the host returns `null` / `undefined`. A view can carry either
  `{ "tr": …, "en": … }` (resolved by the renderer, unchanged) or the
  localization keys a legacy host already owns. `$…` expressions stay data.
  Adapters seed `FormContext.localize` through `hostTextLocalizer(delegate)`
  (React / Vue / Angular, nested components inherit); a delegate without the
  hook sees no change.

### Fixed

- **Hosted `Dialog` body scrolls inside its frame.** `.d-feedback` gets
  `max-height: 100%; min-height: 0` and `.d-feedback__body` `min-height: 0;
  overflow: auto` (React, Vue), so a long body scrolls under a fixed title
  and actions when the host popup bounds the height, instead of growing past
  it. Parity with the Flutter adapter. (#465478)

## [0.7.2] — 2026-09-18

### Added

- **`Skeleton` component** (all adapters) — CSS-shimmer placeholder blocks
  (`rows`, `variant: text | card`) for content still loading.
- **`ForEach.search`** — client-side filter of an already-loaded list
  (`{"query": "$form.q", "fields": [...]}`; case-insensitive, Turkish ı/İ
  folded) and **`ForEach.loading`** — node rendered while `source` has not
  resolved yet (typically a `Skeleton`). Engine helper `applyForEachSearch`.
- **`ForEach.gap`** documented in the vocabulary (Flutter spacing; web rows
  already inherit the enclosing container's gap).

## [0.7.1] — 2026-09-17

### Added

- **`TextField.trailing` — a text action inside the field.** `{ label, action?, command? }`
  renders a text-styled button in the input's trailing area (left of the
  password reveal toggle) and dispatches through the ordinary action pipeline
  **without validating the form**: a login form's "Forgot?" must not be blocked
  by an empty required password. `action` defaults to `submit`; the host
  interprets `command` (e.g. `urn:vnext:flow:start:…` opens another flow).
  Optional `tone` (`success`/`warning`/`error`/`info`) colours the label from the
  palette's status roles — no literal colours in JSON.
  React / Vue: `.d-field__trailing` overlaid on the input; Angular: `matSuffix`
  `mat-button`. Engine: `trailingActionDescriptor()` forces `validate: false`.

- **`x-controlLabels` — the captions a widget draws itself, declared on the
  schema property.** Every other input in this SDK shows exactly two kinds of
  text and both already came from the bound property: the label (`x-labels`,
  which `floatingLabel: 'never'` also renders as the placeholder) and a message
  (`x-errorMessages`). `FilePicker` is the first control with CHROME of its own
  — a pick button, a remove button, a line stating the ceiling — and those had
  nowhere to come from, so they were English literals repeated in four adapters
  and stayed English when the person switched the app to Turkish.

  They now read from `x-controlLabels` on the same property, through
  `getFieldControlLabel`, which is `getFieldErrorMessage` with a different block
  name and the same `{tr, en}` shape. Keys for `FilePicker`: `choose`, `add`,
  `replace`, `remove`, `clear`, `busy`, `hint`, `hintMulti`, `limit`, `usage`.
  The three sentences about limits take `{perFile}`, `{maxFiles}`, `{total}`,
  `{used}` and `{count}`; the button captions take none. An undeclared key falls
  back to `FILE_PICKER_CONTROL_DEFAULTS`, which is the exact text the adapters
  rendered before this existed — a definition that declares nothing renders
  unchanged.

  The vocabulary is the WIDGET's, not the extension's: `view-model-vocabulary.json`
  accepts arbitrary keys, so the next component with chrome of its own declares
  its keys in its own docs and needs no meta-schema change. The alternative —
  a key-based string bundle at the root of `view.json` — was rejected for now:
  no text in this SDK has ever come from the view, and inverting that for four
  buttons would be a second localization mechanism to keep in sync with the
  first.

  This closes the gap the previous entry left open: the at-rest hint
  ("No file chosen · up to 1.0 MB") is now `hint`/`hintMulti` and no FilePicker
  string is hardcoded in any adapter.

### Changed

- **`FilePicker` refusals now read from the schema, like every other field's
  message.** The node's wording was a fixed English string — the one thing in
  this vocabulary a definition could not translate — so a Turkish form showed
  "Dosya Adı boş bırakılamaz." beside "File is 2.5 MB — the limit is 1.0 MB".
  The five verdicts plus the two capability failures are now looked up through
  the same `getFieldErrorMessage` that resolves `required` and `minItems`,
  under the same `x-errorMessages` block and the same `{tr, en}` shape:
  `oversize`, `wrongType`, `empty`, `count`, `total`, `readFailed`,
  `pickerUnavailable`. `{size}`, `{limit}`, `{type}`, `{accept}`, `{max}`,
  `{total}` and `{totalLimit}` are filled into a declared message; one written
  without placeholders is shown verbatim. An undeclared key keeps the built-in
  English, so nothing that renders today changes.

  No new mechanism and no host wiring: the engine takes a lookup FUNCTION
  rather than a schema, which is what keeps `filePicker.ts` free of imports and
  the decisions identical on all four adapters. A host dictionary was the other
  candidate and was rejected — the message belongs beside the contract that
  declares the field, not in the app that happens to draw it.

### Fixed

- **`set` accepts a bare schema field as `data`** (`"data": "restrictionType"`
  → `$form.restrictionType`), as the vocabulary always documented.

- **Watchers fire on async sources (Vue).** `$subFlow.*` / `$subProcess.*`,
  `$lookup.*` and `instanceData` changes now re-run view watchers, as the
  React adapter's data tick already did — so a view can seed a field from a
  sub-flow's current value with `set` + `mode: fill-empty`.

## [0.7.0] — 2026-09-15

### Added

- **`FilePicker` — ask the person for a document.** THE ONE INPUT A DEFINITION
  CANNOT COMPOSE: no arrangement of `Button`, `ForEach` and `select` makes an
  operating system offer its own filesystem, which is the test this vocabulary
  applies before adding a node at all. Everything around the dialog stays where
  it already lives — the label is the schema's `x-labels`/`title`, requiredness
  its `required` (an `allOf`/`if`/`then` branch included), visibility its
  `x-conditional` — and the picked file lands in `bind` like any other field's
  value. **There is no upload**: the file becomes base64 in the form data and
  travels in the ORDINARY TRANSITION BODY, exactly like a text field's string —
  no side channel, no endpoint, no attachment id. The value is one object per
  file, `{name, mimeType, size, content}`, `content` base64 with no `data:`
  prefix.

  Ceilings are contract terms rather than UI politeness, because the base64
  sits in the instance data and is carried on EVERY read of that record while
  inflating by 4/3: `maxSizeBytes` defaults to 1 MiB per file and cannot be
  switched off. `multiple: true` turns the node into a picker for a SET, where
  the bind ALWAYS holds an array (five files, one, or `[]`), picking ADDS
  rather than replaces, and `maxFiles` (5) and `maxTotalBytes` (4 MiB) come
  into force beside the per-file ceiling — the total is the one that actually
  protects the record, since five files that each pass a 1 MiB gate are 5 MiB
  of documents. An untouched picker writes NOTHING (absent, never `[]`).

  Every loss is reported at the level that matches what happened — refused
  (warn, naming what and why), no host wired (error, naming the consequence),
  unreadable (warn, field left empty), cancelled dialog (debug, because
  changing your mind is not a failure). Logs carry names, types and sizes and
  NEVER the content.

  KNOWN LIMITATION: the node's own refusal wording is a fixed English string.
  Unlike a schema-declared message it cannot be overridden through
  `x-errorMessages`, so a Turkish form shows an English refusal. A host-fed
  string dictionary is the principled fix and is tracked separately.

- **`FilePicker.fields` — rename the four stored keys to a schema that already
  exists.** Absent means the canonical `{name, mimeType, size, content}`, which
  is what a new schema should use. It exists because document schemas already
  in production (IDM/DYS) spell the same four facts `{fileName, contentType,
  fileContext}`, and rewriting them is a migration nobody has budgeted —
  mapping at the edge is cheaper than a shape the backend does not speak. It
  RENAMES ONLY: still one object per file, still the ordinary transition body,
  and an omitted key keeps its canonical name.

- **`PseudoViewDelegate.readFile` — the platform half of the picker, and
  nothing else.** It turns the machine's file handle into bytes and talks to no
  server; an earlier draft of this seam was called `uploadFile`, and that word
  invented a transport this SDK does not have and is not meant to grow.
  Optional: a client with no file-taking definition wires nothing and loses
  nothing, and a definition that asks for one in such a client reports the gap
  at error rather than presenting a dead control.

### Fixed

- **A required list field with nothing in it passed the submit gate in
  silence.** The gate asked `value === undefined || null || ''` and `[]` is
  none of those, so an empty array read as an answer. It now judges a
  list-valued field as a list (`validateArrayField`): empty means absent when
  the field is required, and the schema's own `minItems` / `maxItems` count
  contract actually runs — previously both were declared and never enforced.
  REQUIRED wins over `minItems` on an empty list, because "this field is
  required" is what a person expects to read on something they have not filled
  in. Pre-existing and independent of `FilePicker`; the multi-mode picker,
  whose bind always holds an array, is what made it visible.

## [0.6.0] — 2026-09-14

### Fixed

- **`insertNodeAtPath` no longer wraps a single-node slot in an array.** The
  singular-slot case was hardcoded to `template`, so a designer inserting into
  any other single `componentNode` slot (`body`, `appBar`, `leading`,
  `trailing`, `anchor`, `header`, `bottomNavigationBar`,
  `floatingActionButton`) turned it into a one-element array — a tree the
  schema rejects, since each is declared as a lone `$ref` on an
  `additionalProperties: false` owner. All nine are now recognised
  (`SINGULAR_SLOT_KEYS`); array slots (`children`, `actions`) are unchanged.

### Added

- **`IconButton.size`** — the same `sm` / `md` / `lg` / `xl` token `Icon`
  takes, applied as the `d-icon--<size>` / `pseudo-icon--<size>` class so the
  pixels stay in CSS where a host overrides them. `xl` gained a rule in the
  React and Vue stylesheets (Angular already had one), and the vocabulary's
  `Icon.size` now declares `xl` too — the adapters had supported it all along.

- **`IconButton.label`** — the button's accessible name, not visible text.
  Rendered as `aria-label` + `title` (React / Vue / Angular) and as the tooltip
  on Flutter, which also exposes it to the accessibility tree. An icon-only
  button has no text of its own, and drawing the label would defeat the fixed
  width an icon action is chosen for.

- **`Scaffold`: a view can declare its own PAGE FRAME.** New root-only node
  type with `appBar`, `body`, `bottomNavigationBar` and
  `floatingActionButton` slots, so the top app bar — its title and its actions
  — comes from the view JSON instead of client code. React, Vue and Angular
  render it as a page shell (`.d-scaffold` / `.pseudo-scaffold`: chrome pinned
  top and bottom, body taking the rest); Flutter renders a real Material
  `Scaffold`. Designer pointers for the slots are `appBar`, `body`,
  `bottomNavigationBar`, `floatingActionButton` and are identical across the
  three adapters.

  **Host contract:** `viewDeclaresOwnFrame(view)` (new engine export) is the
  one question a host asks before framing a surface. When it answers `true`
  the host must render the view bare — no chrome, padding or safe-area inset
  of its own — or the page grows two app bars. Only full-page presenters
  should ask; popup / bottom-sheet hosts must ignore it.

- **Form auto-seeded from `instanceData` (SDK rule, all adapters).** A bound
  field opens on the record's value under the same key: for every top-level
  schema property present in `instanceData`, `PseudoView` deep-copies it into
  the form at mount (engine `seedFormFromInstance`, exported). Nested objects
  come along, so dotted binds (`limitDraft.accounts.timeDeposit.daily`)
  resolve. Precedence: schema `default` < instance value < host `formData`
  (an explicit draft). A later `instanceData` change (Vue / React) fills only
  still-empty fields, never the user's in-progress edits. Hosts no longer
  need to pass their record as `formData` to pre-fill a view.

- **Composites ship inside the package.** `composites/<ref>/{view,schema}.json`
  at the repository root — today `flow-completion-page` and
  `update-password-page` — is embedded as generated source
  (`src/composites/bundledComposites.g.ts`), so a host answers
  `{ "type": "Component", "ref": "update-password-page" }` without a component
  endpoint, a per-domain publish or a gateway route. `loadBundledComposite(ref)`
  is shaped as `PseudoViewDelegate.loadComponent` for a one-line hand-over;
  `getBundledComposite` returns `undefined` for an unknown ref so a host can
  fall through to its own source; `hasBundledComposite` / `bundledCompositeRefs`
  list what this build knows. Twin of the Dart `BundledComposites` class;
  `scripts/sync-composites.mjs` regenerates both embeddings (`--check` for CI).

- **`set` action gained a `mode` (`overwrite` / `fill-empty` / `once`)** (all
  adapters + watchers). `overwrite` (default) always writes; `fill-empty` and
  `once` write only when the target is currently empty (`null` / `undefined` /
  `''`) and skip otherwise — so a view can seed a default without clobbering a
  value the user (or a prior write) already set. `0` and `false` count as
  filled. The `set` write semantics (target parsing, mode skip, error clearing)
  now live in a single engine helper, `applySetAction`, that the three adapters'
  `applySet` and the watcher engine all call — replacing four hand-rolled copies
  and matching the Flutter engine's shared `SetAction`. New engine exports
  `applySetAction`, `parseSetMode`, and the `SetMode` type; `ActionDescriptor`
  gains `mode`; vocabulary updated (both `actionDescriptor` forms). Mirrors the
  Flutter engine's `SetMode`.

- **Angular adapter reaches full Flutter component parity.** Eighteen node
  types that the Vue / React adapters already rendered were missing from the
  Angular `DynamicRenderer` and now render there too: `Image`, `Chip`, `Badge`,
  `Tooltip`, `ListTile`, `IconButton`, `FAB`, `Stack`, `Toolbar`, `AppBar`,
  `ExpansionPanel`, `Stepper`, `Snackbar`, `NavigationBar`, `AutoComplete`,
  `Menu`, `NavigationDrawer`, `BottomSheet` and `SideSheet`. Each reuses the
  existing engine helpers (expression / conditional / LOV resolution, the
  action pipeline) and its closest Angular Material analogue — overlay surfaces
  (`BottomSheet` / `SideSheet` / `NavigationDrawer`) render as a declarative
  backdrop + panel driven by the node's `visible` expression, matching the
  React / Vue pattern rather than an imperative Material service. Angular now
  covers every component the Flutter adapter supports; only the Vue / React-only
  `ArrayField` and `Carousel` remain unimplemented there (Flutter lacks them
  too). New Material module imports: badge, chips, tooltip, list, toolbar,
  expansion, stepper, menu, autocomplete, slide-toggle, slider, button-toggle,
  progress-bar.

### Changed

- **`Component.ref` may be a resource URN.** The view vocabulary accepted only a
  plain slug; `ref` is now `oneOf` two named defs, `plainRef` (`^[a-z0-9-]+$`)
  and `resourceUrn` (`urn:<ns>:res:<res-key>:<domain>:<key>[:<version>]`), so a
  view can embed a composite that another domain owns. Resolution stays with
  the host's `loadComponent`; the adapters never validated `ref` at runtime, so
  behaviour is unchanged.

## [0.5.0] — 2026-09-07

### Changed

- **`ImagePicker.initialValue` is deprecated** (all adapters). Still honoured
  (one `warn` log per page); expose the current value under the bind key in
  the instance data instead — the form auto-seed pre-selects it.

- **`select` action is deprecated in favour of `set`** (all adapters). `select`
  still writes the value inline (`$form.*` / `$ui.*`, host not called), but its
  first use logs a one-time deprecation warning naming `set` as the
  replacement. Existing views keep rendering; migrate at your own pace.
  Mirrored in Dart.

- **Magic strings replaced with type-safe engine models.** `ExpressionRoot`
  (namespace tokens + `rootPrefix` / `hasRoot` / `stripRoot`),
  `ConditionOperator` (`CONDITION_OPERATORS` evaluator map +
  `isConditionOperator`) and `PseudoComponentType`
  (`keyof typeof componentMeta`) centralize the hard-coded `'$param.'` /
  `.slice(6)` offsets and the `x-conditional` operator switch. Behaviour
  unchanged. Mirrored in Dart.

- **`inputmode=numeric` survives lookarounds in `pattern`.** The digits-only
  scanner in `inputConstraints.ts` bailed out on any group, so a business-rule
  pattern such as `^(?!(\d)\1{5}$)(?!123456)[0-9]{6}$` (6-digit PIN, not
  all-same, not a run) got a plain text input while its sibling `^[0-9]{6}$`
  fields got a numeric one. Lookarounds are zero-width — they decide WHICH
  digit strings match, never what characters make them up — so the scanner now
  steps over `(?=…)` `(?!…)` `(?<=…)` `(?<!…)` and lets the consuming tokens
  decide; other groups remain unmodelled (no restriction). Mirrored in Dart.

- **`command` may be a `$` expression** (all adapters, via the action
  pipeline). `"command": "$param.submitCommand"` is resolved on the node's
  context before `onAction`; literals pass through and the SDK still does not
  interpret the value. Lets a shared composite carry its own submit button
  while the host view supplies the transition URN through `bind`. An
  expression that resolves to nothing dispatches without a command and logs a
  warning. New engine export `resolveCommand`.

- **`Icon` gained `variant`** (`success` / `error` / `warning` / `info`): the
  `d-icon--<variant>` (React, Vue) / `pseudo-icon--<variant>` (Angular) class
  colours the icon from the same `--p-*` tokens the Snackbar variants use.
  JSON still never carries a colour; omitted → inherited colour.

- **Node-level `x-conditional` is now part of `view-vocabulary.json`** (every
  component definition; `$defs.nodeConditional`).

- **`x-conditional` gained the `matches` operator** — a regex test on the
  field's string form (empty never matches, an invalid pattern is `false`, not
  a throw). With node-level `x-conditional` this renders a live rule checklist
  (✓ / •) purely from backend JSON. Mirrored in Dart; vocabulary updated.

- **`x-validation` object form is evaluated by the engine** (React, Vue,
  Angular). `{ "rule": "equalsField" | "notEqualsField", "parameters": {
  "field": "<sibling>" }, "errorMessages": {…} }` is a built-in cross-field
  rule — password / confirm is the canonical case — checked on change and on
  submit, and re-judged when the SIBLING changes (`revalidateCrossFieldDependents`).
  `x-validation: true` and unknown rules keep reaching `onValidationRequest`.
  New engine exports: `validateCrossField`, `crossFieldDependents`,
  `needsDelegateValidation`, `revalidateCrossFieldDependents`, `readFormPath`.
  `SchemaProperty['x-validation']` is now `boolean | ValidationDefinition`.

### Fixed

- **Node-level `x-conditional` is honoured** (React, Vue, Angular). Only a bound
  field's schema rule was evaluated; an `x-conditional` written on a Row, Text
  or Icon node was ignored, so a JSON-only rule checklist could never hide its
  twin. The renderer now reads the node's own rule when the bound property has
  none — the precedence the Flutter adapter already had.

### Added

- **View-level `watchers[]`** (Vue, React, Angular). A view may declare
  watchers — `{ on: "<expr>", action | cases }` — that fire only when the `on`
  value CHANGES (edge, never on first render). The simple form runs on a truthy
  value; `cases` branch on the changed value with `when` rules (same shape as
  `x-conditional`) and a `fallback` that runs on any change. Actions write
  `formData` / `uiState` (`set` / legacy `select`), load an `x-lookup`
  (`lookup`, awaited so a following `set` reads it), or dispatch a domain verb;
  writes cascade into other watchers until quiescent (depth-guarded). New engine
  export `WatcherRunner`; vocabulary `$defs.watcher`. Mirrors the Flutter engine.

- **`Switch` dispatches an `action` on toggle** (Vue, React, Angular). A `Switch`
  with `action` (+ optional `command`) now writes its bound value and then
  dispatches on EVERY toggle — both on and off — matching the Flutter adapter, so
  a router that branches on the new boolean value fires in both directions.
  Vocabulary: `switchComponent` gains `action` / `command`.

- **`set` and `lookup` action verbs** (all adapters). `{ "action": "set",
  "data": "$form.city", "value": … }` writes the value inline (host not
  called) and clears the target field's stale error — the supported
  replacement for the legacy `select`. `{ "action": "lookup", "name":
  "<x-lookup>" }` loads a lookup on demand (awaited, so a following `set` reads
  the fresh `$lookup.<name>`); an `x-lookup` with `trigger: "manual"` opts out
  of auto-load and is fetched only when a `lookup` action asks for it. New
  `ActionDescriptor` fields `data` / `name`, `LookupDefinition.trigger`, and
  engine exports `parseWriteTarget` / `loadLookupByName`. Vocabulary updated
  (both `actionDescriptor` forms). Mirrored in Dart.

- **`$default.<field>` expression namespace.** Resolves to a schema property's
  `default`, walking nested `properties` (`$default.address.city`), so a view
  can seed or reset a field to its schema default without hard-coding the
  value. Mirrored in Dart.

- **`PseudoViewDelegate.resolveImageSource?(source)`.** An `Image.source`
  the browser cannot fetch as-is (a URN, an asset key — anything but
  `http(s):`/`data:`/`blob:`) is offered to the delegate, which returns the
  URL to render or `null` to keep the source unchanged. Lets a view name a
  brand illustration platform-agnostically while each client owns the
  mapping; the Flutter adapter exposes the same seam plus a widget-level
  `registerImageBuilder`. Wired in all three adapters.

- **`ImagePicker` gained `initialValue`.** Seeds `formData[bind]` once,
  only while the field has no value yet, so a server-side current choice
  renders pre-selected and submits unchanged when the user does not touch
  the grid — the anti-phishing image-change flow passes
  `"$instance.currentImage.imageDefinitionId"`. `'$'`-prefixed values are
  expressions; anything else is a literal. A user tap overwrites it like
  any selection, and an unresolvable expression leaves the field unset.

### Fixed

- **Internal form state no longer shares references with the host's
  `formData`.** All three adapters seeded with a shallow `Object.assign`,
  so nested objects stayed shared between the host's prop and the SDK's
  state, and every dotted-bind write (`limitDraft.a.b`, `permissions.x`)
  mutated the host's object in place. In Vue — where the prop is
  deep-watched — that mutation read as "the host sent new form data", so
  the watcher re-assigned the prop over the internal state and reverted
  the user's top-level edits (the corporate-provision "role snaps back
  after typing a limit" bug). Seeds (`formData`, `instanceData`,
  `uiState`) and the `formChange` payload are now deep clones
  (`clonePlainData`, JSON round-trip — proxy-tolerant like
  `treeUtils.deepClone`); React and Angular got the same treatment since
  they mutated the host's object the same way, just without the visible
  feedback loop. The Flutter adapter is unaffected: it never seeds from a
  host-owned map.

## [0.4.0] — 2026-08-12

### Added

- **Child-instance read-through — `$subFlow` / `$subProcess`.** A parent
  workflow's view can display its sub-flow / sub-process data without that data
  ever being copied into the parent.

  ```
  $subFlow.<parentState>     a single record; the same flow may run at several
                             points in the parent, so the STATE disambiguates
  $subProcess.<flowName>     always an array (1-to-n fan-out), keyed by flow
                             name; plus `.length` and `.$done`
  ```

  Which root a child lands in comes from the runtime's `subFlowType` (`S` /
  `P`), never from where it was authored. Entries are newest-first, so `.0` means
  "the current run".

  Wiring is two things, and if either is missing nothing is fetched (the view
  renders empty and logs one warning): the optional delegate method
  `loadSubInstances`, and `instanceRef` on `PseudoView`. The load is
  reference-driven — a view with no `$sub*` binding calls nothing at all, and only
  the roots a view actually names are requested.

  Implemented for **all three adapters** (Vue, React, Angular). The fetch and its
  out-of-order guard live in `engine/subInstanceLoader.ts` rather than in each
  adapter, so a slow answer for a previous record cannot overwrite a fresh one.

  Full guide, including four authoring rules specific to this engine:
  [`docs/child-instance-read-through.md`](https://github.com/burgan-tech/vnext-client-view-renderer/blob/develop/docs/child-instance-read-through.md).

- **`ImagePicker` component** — vocabulary, component meta, all four adapters and
  tests.

- **`Timer` component** — countdown for OTP / SMS verification flows. Display-only;
  expiry dispatches no workflow action.

- **`TextField` password support** — schema properties with `"format": "password"`
  render masked with a visibility toggle. Vue and React use their PrimeVue /
  PrimeReact `Password` components; Angular binds `[type]` with a suffix icon
  button. The view vocabulary is unchanged — masking is a schema-owned concern.

### Changed

- **BREAKING — cross-adapter input defaults flipped.** When a `TextField` /
  `TextArea` / `NumberField` / `Dropdown` / `SearchField` / `AutoComplete` /
  `DatePicker` / `TimePicker` node omits `floatingLabel` and `focusOutline`, the
  effective defaults are now `floatingLabel: "never"` + `focusOutline: "hidden"` —
  the label stays inside the field as a static placeholder and focus does not
  shift the outline. Consumers that relied on the previous "no override → Material
  default" behaviour must opt in explicitly with `"auto"` / `"always"`, and restore
  the themed focused border with `focusOutline: "default"`.

- Contrast-safe theme roles; inverted / chip `onInverseSurface`; LOV `[*]` path
  parity across adapters.

### Fixed

- **LOV reload when the view swaps under a field.** `useLovLoader` now takes the
  field name as a `Ref` and re-resolves on change, so a `Dropdown` whose schema
  property arrives (or changes) after first render loads its options instead of
  staying empty. Merged to `master` as #69 on 2026-07-09 — after `0.3.0` was
  published and before this branch received it — so **`0.4.0` is the first
  release to contain it**.

- `componentMeta` gained an `ArrayField` entry so the vocabulary-sync guard passes.

### Documentation

- `docs/child-instance-read-through.md` added; README gained a child-read-through
  section and the `loadSubInstances` delegate member; `docs/FEATURE-PARITY.md`
  gained engine-level rows for both new roots, both index forms and interpolation.

### Notes for consumers

Two engine limitations are worth knowing before authoring views, neither new in
this release but both now documented:

- There is **no `{{ }}` string interpolation**. A binding is a whole-string
  expression or literal text, so compose a counter from sibling `Text` nodes.
- Index a group with `.0`, **not** `[0]` — expressions split on `.` and there is
  no bracket tokenizer. (The Flutter SDK accepts both.)

## [0.3.0] — 2026-07-02

### Added

- **JSON-driven theme palette** — TypeScript port of `JsonPalette` plus a CSS
  custom-property bridge, mirroring the Dart SDK's `pseudo_ui/theme` API so one
  brand JSON drives both Flutter (`ThemeData`) and web (CSS variables). Public
  surface: `PseudoColorPalette`, `DefaultMaterialPalette`, `JsonPalette`,
  `paletteToCssVars`, `paletteToCssString`.

### Fixed

- Non-hex CSS colours accepted in `JsonPalette`.
- Bracket access for indexed `JsonRecord` fields, and strict-TS fixes required by
  Angular's `ng-packagr` build.

## [0.2.1] — 2026-06-04

### Added

- Array field handler.

### Fixed

- `x-lov` is watched so a LOV appearing after first render still loads.
- Rendering performance pass.

## [0.2.0] — 2026-06-01

### Added

- Designer-mode render flag for `view.json` editors.
- `componentMeta` and `enumerateBindPaths` builder utilities.
- CSS export for the React adapter; full Material Icons support across React and
  Vue.
- npm publish workflow (trusted publishing / OIDC) and licence file.

### Fixed

- Non-string `bind` no longer crashes the renderer.

## 0.1.x

Initial TypeScript SDK line: engine (expressions, validation, conditional rules,
`$ui` state, accessibility), Vue / React / Angular adapters, nested components,
LOV and lookup data flow. Published as `0.1.1` … `0.1.4`.
