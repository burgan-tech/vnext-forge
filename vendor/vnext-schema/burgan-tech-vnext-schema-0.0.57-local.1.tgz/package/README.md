# @burgan-tech/vnext-schema

JSON Schema definitions for vNext Workflow components validation.

## Overview

This package provides comprehensive JSON Schema definitions used by the vNext ecosystem to validate workflows and components developed with the vNext Workflow product. These schemas ensure consistency and validity of workflow definitions, tasks, views, functions, and other components within the vNext platform.

## Included Schemas

- **Core Schema**: Base schema definition for all vNext components
- **Workflow Definition**: Schema for workflow component definitions (`sys-flows`)
- **Task Definition**: Schema for task component definitions (`sys-tasks`)
- **View Definition**: Schema for view component definitions (`sys-views`)
- **Function Definition**: Schema for function component definitions (`sys-functions`)
- **Extension Definition**: Schema for extension component definitions (`sys-extensions`)
- **Schema Definition**: Meta-schema for schema definitions (`sys-schemas`)
- **Mapping Definition**: Schema for mapping component definitions (`sys-mappings`)
- **Core Header**: Schema for runtime HTTP headers and metadata (`sys-schemas`)

### Supported Task Types

`task-definition.schema.json` validates 21 task types, selected through the `attributes.type` discriminator. Each type has its own `attributes.config` shape:

| `type` | Task | Purpose |
|--------|------|---------|
| `1` | Dapr HTTP Endpoint | Call an external HTTP endpoint through Dapr |
| `2` | Dapr Binding | Invoke a Dapr output binding |
| `3` | Dapr Service | Service-to-service invocation via Dapr |
| `4` | Dapr PubSub | Publish a message to a Dapr pub/sub topic |
| `5` | Human Task | Wait for a human decision |
| `6` | HTTP Task | Direct HTTP call |
| `7` | Script Task | Execute a C# script (`.csx`) |
| `8` | Condition Task | Evaluate a condition |
| `9` | Timer Task | Delay / scheduled continuation |
| `10` | Notification Task | Send a notification |
| `11` | Start Flow Task | Start another workflow instance |
| `12` | Trigger Transition Task | Trigger a transition on an instance |
| `13` | Get Instance Data Task | Read instance data |
| `14` | SubProcess Task | Run a sub-process |
| `15` | Get Instances Task | Query workflow instances |
| `16` | SOAP Task | Call a SOAP service |
| `17` | State Store Task | Read/write a Dapr state store |
| `18` | Cache Aside Task | Cache-aside read-through |
| `19` | Get Instance Task | Read a single instance |
| `20` | Dapr Conversation Task | Dapr conversation (LLM) call |
| `21` | FanOut Task | Run an inner task once per collection item, in parallel, and join the results |
| `22` | External HTTP Task | Same configuration contract as type 6, executed directly by the Orchestrator process instead of being routed through the Execution service |

#### External HTTP Task (`type: "22"`)

Type `22` shares the type-6 HTTP configuration surface unchanged (`url`, `method`, `headers`, `body`,
`contentType`, `timeoutSeconds`, `validateSsl`, `acceptedStatusCodes`) — in the runtime
`ExternalHttpTask` derives from `HttpTask`, so mapping scripts (`task as HttpTask`) work for both.
Only the transport differs: the call runs in-process in the Orchestrator, so no Dapr sidecar,
circuit breaker or remote-invocation timeout participates — the task's own `timeoutSeconds`
(default 30) is the only bound. In this schema both types validate against the same `if/then`
branch; adding an HTTP config field means adding it once, for both.

#### FanOut Task (`type: "21"`)

The FanOut task executes a **referenced inner task** once per item of a runtime-resolved collection, in parallel, then joins the per-item outcomes into a single output.

```jsonc
{
  "type": "21",
  "config": {
    "mode": "inline",                 // only 'inline' is accepted in this phase
    "itemsPath": "$.documents.online", // dot-path into instance data (or use the mapping's ItemSelector)
    "itemAlias": "document",           // readability label for logs/traces only
    "task": {                          // required: the inner task run per item
      "key": "upload-document",
      "domain": "core",
      "flow": "sys-tasks",
      "version": "1.0.0"
    },
    "execution": {
      "maxDegreeOfParallelism": 4,     // default 4
      "itemTimeoutSeconds": 30,        // must be <= batchTimeoutSeconds
      "batchTimeoutSeconds": 120
    },
    "join": {
      "policy": "allSettled",          // all | allSettled | quorum | firstSuccess
      "resultKey": "fanOutResults"     // instance data key for item results + '{resultKey}Summary'
    },
    "errorBoundary": {                 // applied per ITEM, same rule shape as state/transition boundaries
      "onError": [
        { "action": 1, "errorCodes": ["FanOut:ItemTimeout"], "retryPolicy": { "initialDelay": "PT2S" } }
      ]
    }
  }
}
```

Authoring notes:

- Only `config.task` is required; every other member has a runtime default.
- `join.minSuccess` is **required** when `join.policy` is `quorum`.
- Exactly one item source must be configured — either `config.itemsPath` **or** the task mapping's `ItemSelector`, never both and never neither. This rule is enforced by the runtime, not by the schema.
- `execution.itemTimeoutSeconds` must be less than or equal to `execution.batchTimeoutSeconds` (also runtime-enforced).
- A FanOut task cannot reference another FanOut task as its inner task.
- `join.ordered` is accepted for forward compatibility; in `inline` mode item results are always ordered by item index.

## Field Exposure Vocabulary (`view-vocab.json`)

Master-schema properties can declare how their value leaves the runtime. The runtime evaluates them in a
fixed order: **`x-roles` → `x-masking` → `x-encryption`**. A property hidden by `x-roles` is pruned and
never reaches the later keywords.

| Keyword | Shape | Runtime |
|---|---|---|
| `x-roles` | array of `roleGrant` (`{ role, grant: allow \| deny }`) | hides the field from callers the grants refuse |
| `x-masking` | `{ operator: mask \| replace, params?, roles? }` | masks the visible value; `roles` is an **allow-only exemption list** (an allow match sees the raw value) |
| `x-encryption` | `{ source?: runtime, type: none \| hash \| encrypt, params?, roles?, purpose?, redactInLogs?, retentionDays? }` | **`source: runtime`** (the default when absent) — at rest. `hash`: applied when the data is written — the stored and served value is `HASHED:SHA256:<hex>` (HMAC under a salt the runtime generates per instance); irreversible, so no `roles` and no `pattern`/`format`/`minLength`/`maxLength`/`enum`/`const`. `encrypt`: AES-256-GCM token `ENCRYPTED:AES256:i1:…` in the stored instance data (key generated per instance), decrypted for the engine; on the data function an allow-listed caller reads the plaintext, everyone else the token; only instance data is encrypted. `roles` is an **allow-only exemption list**; the metadata fields are not enforced. `transport`/`persisted` were removed (never enforced) — use `encrypt` |
| `x-encryption` | `{ source: client, key, algorithm: HPKE-P256-SHA256-AES128GCM \| RSA-OAEP-256, into?, encoding?, nonce?, envelope?, purpose? }` | **`source: client`** — in transit, client → backend: the client seals the value to the recipient's public key before sending; only the service holding the private key opens it. The runtime accepts it on any schema, the master included, and does nothing with it (no at-rest encryption, no read mask, no filter refusal). The at-rest members are not accepted. Replaces the former `x-encrypt` |
| `x-storage` | `{ binding }` | file offload: the property's file bytes are kept in the named Dapr binding component instead of the instance data; `binding` is required and non-empty, no other fields |

Rules the runtime enforces at publish time for `x-masking` and `x-encryption.type: "hash"` (the vocabulary
expresses the shape; the runtime adds the context): `type: "string"` properties reachable through nested
`properties` (any schema component type; they take effect on the schema a workflow references as its data schema), not together with `x-filterOperators`, `x-sortable` or `x-indexed`, one transform per field
(`x-masking` next to an active `x-encryption` is rejected), and for `hash` a salt configured on the host.

```json
"tckn": {
  "type": "string",
  "x-encryption": {
    "type": "hash",
    "params": { "algorithm": "sha256" },
    "purpose": "PII-Identification",
    "redactInLogs": true,
    "retentionDays": 2555
  }
}
```

```json
"password": {
  "type": "string",
  "format": "password",
  "x-encryption": {
    "source": "client",
    "key": "urn:client:context:read:device:memory:device.hpke.publicKey",
    "algorithm": "HPKE-P256-SHA256-AES128GCM",
    "into": "passwordEnc",
    "envelope": "publicKey"
  }
}
```

```json
"iban": {
  "type": "string",
  "x-masking": {
    "operator": "mask",
    "params": { "keepFirst": 2, "keepLast": 4, "maskingChar": "*" },
    "roles": [ { "role": "morph-idm.auditor", "grant": "allow" } ]
  }
}
```

```json
"accountNumber": {
  "type": "string",
  "x-encryption": {
    "type": "encrypt",
    "roles": [ { "role": "morph-idm.auditor", "grant": "allow" } ]
  }
}
```

The exemption lists of `x-masking` and `x-encryption` take plain `{ "role", "grant": "allow" }` entries only —
no `deny` and no `allOf` / `anyOf`. A caller matching an allow entry sees the raw value (the plaintext, for
`encrypt`); every other caller — including one whose role is misspelled or missing — sees it masked (the
token, for `encrypt`). `hash` takes no `roles`: the digest is irreversible.

## Query and Form Keywords (`view-vocab.json`)

| Keyword | Shape | Notes |
|---|---|---|
| `x-filterOperators` | array of `eq`, `neq`, `gt`, `gte`, `lt`, `lte`, `between`, `contains`, `startsWith`, `endsWith`, `in`, `nin`, `isNull`, `includes` | the names the runtime matches a **declaration** against: a list query's token is mapped first (`ne`→`neq`, `ge`→`gte`, `le`→`lte`, `like`/`match`→`contains`), so declaring the query token (`ge`) makes every such filter fail |
| `x-lov` | `{ source \| items, valueField, displayField, imageField?, filter? }` | exactly one of `source` (a URN, fetched; may interpolate `{{$form.x}}`) and `items` (an expression naming an array already in scope, no request); a `filter` `param` may carry an operator (`status:in`) and a literal `value` may be an array |
| `x-conditional` | `{ showIf?, hideIf?, enableIf?, disableIf? }` of `condition` | operators also include `greaterThanOrEquals`, `lessThanOrEquals`, `startsWith`, `endsWith` |
| `x-errorMessages` | localized text per validation keyword | also `minItems` / `maxItems` |
| `x-order` | number | a generated form's field order, lower first; a stored schema does not keep property order (jsonb) |
| `x-computed` | `{ evaluatedBy: runtime \| client, cases?, fallback?, whenAbsent? }` | a derived, never-stored field (master only). `runtime`: the runtime computes it on every read surface from the caller's already-shaped view (after `x-roles` / `x-masking` / `x-encryption`); `client`: a client evaluates it. Each case / the fallback is a `join` (`fields`, `separator`) or an `arithmetic` (`op`, `fields`) over sibling properties; the first case whose `when` matches wins |

## Role Vocabularies (#153)

A schema plays one ROLE, and what an `x-*` keyword means depends on it. The schema component's
`attributes.type` names the role and selects the vocabulary `schema-definition.schema.json` validates
`attributes.schema` against:

| `attributes.type` | Role vocabulary | `x-indexed` |
|---|---|---|
| `master` | `record-vocab.json` | allowed |
| `transition` | `input-vocab.json` | refused |
| `function` | `input-vocab.json` | refused |
| `component` | `component-vocab.json` | refused |
| absent / `""` | none (no role gate) | refused |

These files compose the existing definitions by role (no definition is duplicated — each `$ref`s
`view-vocab.json` / `data-vocab.json`):

| File | Role | Adds |
|---|---|---|
| `data-base-vocab.json` | shared by both | `x-labels`, `x-enum`, `x-order`, `x-displayFormat`, `x-lov`, `x-lookup`, `x-errorMessages`, `x-validation`, `x-conditional` |
| `record-vocab.json` | a flow's master schema | `x-roles`, `x-masking`, `x-encryption`, `x-storage`, `x-indexed`, `x-filterOperators`, `x-sortable`, `x-computed`, `x-context-target` — `x-encryption` with either `source` (`runtime` applied at rest, `client` accepted and not handled by the runtime) |
| `input-vocab.json` | a transition schema / function `inputSchema` / the dataSchema of a view that submits a move of its own | `x-context-source`, `x-encryption` with `source: client` only (in transit, client → backend) |
| `component-vocab.json` | the dataSchema of an embedded view (`Component ref`) that sends nothing of its own | `x-binding` (the component's input contract) |
| `view-hints-vocab.json` | mixin, every role | `x-helpText`, `x-placeholder`, `x-uiHint`, `x-uiNote`, `x-group` |

A component does not inherit the role of the view that embeds it: the host BINDS its data into the component, and
keeps every role-specific behaviour on its own schema (what is sent and how — `x-context-source`, `x-encryption` with `source: client`; what the
record exposes and copies out — `x-roles`, `x-masking`, `x-context-target`). A component that submits uses a command
the host passes in (`$param.submitCommand`), so the move and its body are still the host's.

`<role>-vocab.json#/definitions/schema` validates a whole schema in
that role, recursively (`properties`, `items`, combinators, definitions): any `x-*` keyword outside the role's
list is refused. `#/definitions/allowedKeywords` carries the same list as data, for a tool that wants to
report rather than refuse.

The schemas `$ref` the vocabularies by `$id`, so a validator must register them before compiling:

```js
const Ajv = require('ajv');
const { addVocabularies, schemaDefinition } = require('@burgan-tech/vnext-schema');
const validate = addVocabularies(new Ajv({ strict: false })).compile(schemaDefinition);
```

## Installation

```bash
npm install @burgan-tech/vnext-schema
```

## Usage

This package is primarily designed to be used with the [@vnext/cli](https://www.npmjs.com/package/@burgan-tech/vnext-cli) tool for workflow development and validation.

### Using with @burgan-tech/vnext-cli

The recommended way to use these schemas is through the official vNext CLI:

```bash
npm install -g @burgan-tech/vnext-cli
```

The CLI automatically uses these schema definitions for:
- Validating workflow definitions
- Checking component structure
- Ensuring compliance with vNext standards
- Development-time validation

For detailed CLI usage and workflow development guide, please refer to the [@vnext/cli documentation](https://github.com/burgan-tech/vnext-cli).

### Programmatic Usage

If you need to access the schemas programmatically:

```javascript
const schemas = require('@burgan-tech/vnext-schema');

// Get specific schema
const workflowSchema = schemas.workflowDefinition;
const taskSchema = schemas.taskDefinition;
const headerSchema = schemas.coreHeader;

// Get schema by type
const coreSchema = schemas.getSchema('core');
const headerSchemaByType = schemas.getSchema('header');

// Get all available schema types
const availableTypes = schemas.getAvailableTypes();
// Returns: ['core', 'workflow', 'task', 'view', 'function', 'extension', 'schema', 'header']
```

## Schema Structure

All schemas follow the vNext component structure with required fields:
- `key`: Component identifier
- `version`: Semantic version (Major.Minor.Patch)
- `domain`: Domain identifier
- `flow`: Flow identifier
- `flowVersion`: Flow version
- `tags`: Component tags
- `attributes`: Component-specific attributes

## Contributing

This package is maintained by the vNext Team. For issues, feature requests, or contributions, please visit the [GitHub repository](https://github.com/burgan-tech/vnext-schema).

## License

MIT

## Support

For support and questions:
- GitHub Issues: [https://github.com/burgan-tech/vnext-schema/issues](https://github.com/burgan-tech/vnext-schema/issues)

---

**Note**: This package is part of the vNext ecosystem and is primarily intended for use with the official vNext CLI tools and vNext Workflow platform. 

### Schema component purpose

Schema component documents (`sys-schemas`) state their role in the optional `attributes.type`:
`master`, `transition`, `component` or `function` (see [Role Vocabularies](#role-vocabularies-153)).
It may be omitted or `""` (no role). Any other value — including the legacy `workflow`, `schema`,
`view`, `headers` — is refused; migrate a flow's master to `master`, a transition / function input
to `transition` / `function`, an embedded view's dataSchema to `component`, and a schema that
serves more than one role to no type. Only `master` allows `x-indexed` metadata (including `false`).
There is no component root `type` field, and nested JSON Schema `type` keywords retain their meaning.

For an explicit master schema, `x-indexed` must be boolean. `true` requires an explicit scalar
`type` of `string`, `number`, `integer`, or `boolean` beneath fixed object `properties`; date fields
remain strings with `format: "date-time"`. Nested objects may omit their object type. The first path
segment must match `[a-zA-Z][a-zA-Z0-9_]*`; subsequent segments allow `[a-zA-Z0-9_]+`.
Arrays, object-valued indexed fields, ambiguous types, references, and conditional/composed indexed
nodes or ancestors are rejected. Index requests in definitions, pattern properties, and other dynamic
schema locations are also rejected. Unrelated conditional siblings and literal `examples`, `default`,
`const`, or `enum` data are unaffected. `false` disables indexing and does not require a scalar type;
it is still invalid outside an explicit master schema. Omitting `x-indexed` requests no index and
validation does not insert a default value.

For example, inside a component with `attributes.type: "master"`:

```json
{
  "type": "object",
  "properties": {
    "amount": { "type": "number", "x-indexed": true },
    "customer": {
      "type": "object",
      "properties": {
        "name": { "type": "string", "x-indexed": true }
      }
    }
  }
}
```

This validates index eligibility only. The CLI generates SQL and the DBA schedules execution;
validation does not create indexes or change filter/sort permissions.
